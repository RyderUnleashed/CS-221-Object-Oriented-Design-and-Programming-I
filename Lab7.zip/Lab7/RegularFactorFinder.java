import java.util.Scanner;
/**
 * This program prompts the user to input a number and finds all the factors for that number.
 * If a number is prime, the program will simply output '1' and the user's inputted number.
 *
 * @author Alex Griep
 * @version 10/27/2022
 */
public class RegularFactorFinder
{
    public static void main(String[] args)   {
        Scanner input = new Scanner(System.in);
        int userNum;
        int i = 1;
        System.out.print("Enter a number: ");
        userNum = input.nextInt();

        //Program intializes the loop
        while (i <= userNum)   {
            //Program checks to the user's number is divisible by the iteration 'i'
            if (userNum % i == 0)   {
                //Program checks to see if it's prime by seeing if it'll carry a remainder
                if (userNum % 2 != 0)   {
                    System.out.println(i + " " + userNum);
                    System.out.println(userNum + " is prime");
                    i = userNum;
                }
                else   {
                    System.out.print(i + " ");
                }
            }
            i++;
        }
    }
}
