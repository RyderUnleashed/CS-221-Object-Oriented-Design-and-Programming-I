import java.util.Scanner;
/**
 * Write a description of class SmallestFactorFinder here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SmallestFactorFinder
{
    public static void main(String[] args)   {
        Scanner input = new Scanner(System.in);
        int userNum;
        int i = 2;

        System.out.print("Enter num: ");
        userNum = input.nextInt();
        input.nextLine();
        System.out.print("1" + "  ");
        
        while (i <= userNum)   {
            if (userNum % i == 0)   {
                System.out.print(i + "  ");
                userNum = userNum / i;
            }
            else   {
                ++i;
            }
        }
    }
}
