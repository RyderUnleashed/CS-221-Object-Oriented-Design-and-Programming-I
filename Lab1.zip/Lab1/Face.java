
/**
 * This quick program displays an ASCII tiki head.
 * This is an assignment for CS221 offered by UW-Oshkosh
 *
 * @author Alex Griep
 * @version 9/9/2022
 */
public class Face
{
    public static void main (String[] args) {
        //draws the top of the ASCII tiki head
        System.out.println("  _ _ _");
        //draws the forehead of the ASCII tiki head
        System.out.println(" | _ _ |");
        //draws the eyes of the ASCII tiki head
        System.out.println(" | - 0 |");
        //draws the ears and nose of the ASCII tiki head
        System.out.println("{|  >  |}");
        //draws the puckered mouth of the ASCII tiki head
        System.out.println(" |[---]|");
        //draws the chiseled chin of the ASCII tiki head
        System.out.println(" |_ _ _|");
    }
}
