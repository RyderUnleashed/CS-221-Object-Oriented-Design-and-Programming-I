
/**
 * I like stromboli. My favorite band are the Black Angels.
 * I chose UWO because it's close to home and affordable.
 * My plan for the future is to make the world a better place.
 *
 * @author Alex Griep
 * @version 9/9/2022
 */
public class FirstLab
{
    public static void main (String[] args) {
        System.out.println("Hello World!");
        System.out.print("Alex");
        System.out.print(" Griep");
    }
}
