import java.util.Scanner;
import java.text.DecimalFormat;
/**
 * This program simulates the purchase of cupcakes, modifying the price based on a variety of conditions.
 * It'll then calculate the final price based on if the user is picking up the order or having it delievered
 *
 * @author Alex Griep
 * @version 10/7/2022
 */
public class TitanTreats
{
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        DecimalFormat price = new DecimalFormat("0.00");
        final double BASE_FEE = 2.50;
        int numCupcakes = 0;
        int numFrosting = 0;
        int numSprinkles = 0;
        int numFilling = 0;
        double totalCost = 0;
        String userAddress;
        
        //Greeting an prompt for user to place their order
        System.out.println("Welcome to Titan Treats!");
        System.out.println("Please place your cupcake order:");
        System.out.println();
        
        //User enters number of cupcakes
        System.out.print("Number of cupcakes: ");
        numCupcakes = input.nextInt();
        input.nextLine();
        if (numCupcakes == 0)   {
            System.out.println("No cupcakes will be ordered. Cancelling transaction.");
            return;
        }
        
        //User enters number of frosting colors
        System.out.print("Number of frosting colors (1 included): ");
        numFrosting = input.nextInt();
        input.nextLine();
        
        //User enters number of sprinkles colors
        System.out.print("Number of sprinkles colors (1 included): ");
        numSprinkles = input.nextInt();
        input.nextLine();
        
        //User enters number of fillings
        System.out.print("Number of fillings (0 included): ");
        numFilling = input.nextInt();
        input.nextLine();
        
        //User may choose to enter address
        System.out.print("Delivery address (or just press 'Enter' for pickup instead): ");
        userAddress = input.nextLine();
        
        //Program calculates total cost based on user's input
        if ((numCupcakes > 0) && (numCupcakes < 5))   {
            totalCost += (numCupcakes * 1.50) + BASE_FEE;
        }
        else if ((numCupcakes >= 5) && (numCupcakes <= 9))   {
            totalCost += (numCupcakes * 1.25) + BASE_FEE;
        }
        else if ((numCupcakes >=10) && (numCupcakes <= 19))   {
            totalCost += (numCupcakes * 1.00) + BASE_FEE;
        }
        else if (numCupcakes >= 20)   {
            totalCost += (numCupcakes * 0.75) + BASE_FEE;
        }
        if ((numFrosting > 1) && (numSprinkles > 1))   {
            totalCost += 1.50;
        }
        else if ((numFrosting > 1) || (numSprinkles > 1))   {
            totalCost += 1.00;
        }
        if (numFilling > 0)   {
            totalCost += (numFilling * 2.00);
        }
        
        //Program sums up order info and delivery/pickup info
        if (userAddress.isEmpty())   {
            System.out.println();
            System.out.println("Thank you for your order!");
            System.out.println("That will be $" + price.format(totalCost) + " for pickup");
        }
        else   {
            totalCost += 3.99;
            int indexOfFirstComma = userAddress.indexOf(",");;
            int indexOfSecondComma = userAddress.indexOf(",", indexOfFirstComma + 1);
            int indexOfThirdComma = userAddress.indexOf(",", indexOfSecondComma + 1);
            int indexOfSpace = userAddress.indexOf(" ", indexOfSecondComma);
            int indexOfSecondSpace = userAddress.indexOf(" ", indexOfSpace + 2);
            System.out.println();
            System.out.println("Thank you for your order!");
            System.out.println("That will be $" + price.format(totalCost));
            System.out.println();
            System.out.println("Delivering to: ");
            System.out.println("Street: " + userAddress.substring(0, indexOfFirstComma));
            System.out.println("City: " + userAddress.substring(indexOfFirstComma + 2, indexOfSecondComma));
            System.out.println("State: " + userAddress.substring(indexOfSecondComma + 2, indexOfSpace + 3));
            System.out.println("ZIP:" + userAddress.substring(indexOfSpace + 3, indexOfSecondSpace + 6));
        }      
    }
}
