import java.util.Scanner;
/**
 * Instance variables and methods created to be used in YahtzeePlayer, no constructor is given so values are default.
 *
 * @author Alex Griep
 * @version 12/25/2022
 */
public class Yahtzee
{
    //Instance variables
    private Die die1; //Creates a die object
    private Die die2; //Ditto ^
    private Die die3; //Me too ^^
    private boolean gameOver = false; //End condition for outer boolean loop in YahtzeePlayer
    private boolean turnEnded; //End condition for inner boolean loop in YahtzeePlayer
    private boolean rollsUsed; //End condition that will prevent user from rolling another die
    private boolean invalidOption; //End condition for promptUser
    private int rollsDid = 0; //Counter for boolean end condition above ^
    private boolean didYahtzee = false; //End condition for whether or not the user can score another yahtzee score
    private boolean didStraight = false; //End condition for whether or not the user can score another straight score
    private boolean didChance = false; //End condition for whether or not the user can score another chance score
    private boolean validDie; //End condition for pickDieToRoll
    private int userChoice = 0; //Return variable for instance methods, determind by the scanner
    private int finalScore = 0; //Keeps track of the score during the game
    Scanner scanner = new Scanner(System.in); //Scanner to allow user to input an integer (will crash if not integer but it's assumed they know)

    /**
     * Boolean end condition used in YahtzeePlayer. If all scores boolean flags are tripped, it'll send back a boolean value of 'true' and exit the outer loop created.
     * @author Alex Griep
     * @return boolean value representing whether or all scores have been used or not
     */
    public boolean isOver()   {  //Method here is an end condition for the game
        if (didYahtzee && didStraight && didChance)   { //If all end conditions for the score methods are true, the game is ended
            gameOver = true;
        }
        return gameOver; //Boolean value of 'true' is returned
    }

    /**
     * Initializes and resets some instance variables and gives the user new dice to play with in YahtzeePlayer.
     * @author Alex Griep
     */
    public void startTurn()   { //Method here resets various boolean conditions, counters, and dice
        rollsDid = 0; //Resets the counter for the rollsUsed end condition
        rollsUsed = false;
        turnEnded = false; //Resets the end condition for turnOver
        die1 = new Die(); //At the start of every turn, give the user three more dice to play with
        die2 = new Die();
        die3 = new Die();
    }

    /**
     * Boolean end condition used in YahtzeePlayer to exit a turn phase. If a single score is used, it'll send back a boolean value of 'true' and exit the inner loop created.
     * @author Alex Griep
     * @return Boolean value representing whether a score has been used or not
     */
    public boolean turnEnded()   {
        return this.turnEnded; //Simply resets a 'true' value to break out of the loop in YahtzeePlayer
    }

    /**
     * Gathers the numbers of the die objects and displays them when called.
     * @author Alex Griep
     */
    public void displayDice()   {
        System.out.println("Dice are: " + die1.getValueOf() + " " + die2.getValueOf() + " " + die3.getValueOf()); //Displays the integer values 
    }

    /**
     * Displays options the user can choose during their turn in YahtzeePlayer. If one of the boolean flags for their rolls or scores have been tripped, the option won't be displayed.
     * @author Alex Griep
     */
    public void displayOptions()   { //Method displays options for the user
        if (!rollsUsed)   { //Checks end condition for rolling dice
            System.out.println("1 to roll a single dice."); 
        }
        if (!didYahtzee)   { //Checks end condition for if they scored a yahtzee already
            System.out.println("2 for yahtzee score.");
        }
        if (!didStraight)   { //Checks end condition for if they scored a straight already
            System.out.println("3 for straight score.");
        }
        if (!didChance)   { //Checks end condition for if they scored a chance already
            System.out.println("4 for chance score.");
        }
    }

    /**
     * Prompts the user to enter a choice based on the options displayed in displayOptions(). If a boolean flag has been tripped for one of the options,
     * it'll prevent the user from choosing that option.
     * @author Alex Griep
     * @param Scanner to allow the user to enter a number
     * @return Integer sent by the user saved in a variable named, "userChoice"
     */
    public int promptUser(Scanner scanner)   { //Prompts the user to enter a choice with the scanner as a parameter
        System.out.print("Enter a choice: ");
        userChoice = scanner.nextInt(); //Saves the choice as a variable to check with a switch case
        switch (userChoice)   { //To check what the user entered
            case 1:
                invalidOption = (rollsUsed) ? true : false; //If they used all their rolls, set invalidOption as true, else false
                break;
            case 2:
                invalidOption = (didYahtzee) ? true : false; //If they scored a yahtzee already, set invalidOption as true, else false
                break;
            case 3:
                invalidOption = (didStraight) ? true : false; //If they scored a straight already, set invalidOption as true, else false
                break;
            case 4:
                invalidOption = (didChance) ? true : false; //If they scored a chance already, set invalidOption as true, else false
                break;
            default:
                System.out.println("ERROR, try again."); //Default case as a safety measure
                break;
        }
        if (invalidOption)   { //If invalidOption is true
            System.out.println("ERROR, try again."); //Display error message
            promptUser(scanner); //Prompt the user again
        }
        return userChoice; //return what they picked
    }

    /**
     * Prompts the user to choose a die to roll. If the boolean flag for their rolls have been tripped, it'll print an error message.
     * @author Alex Griep
     * @param Scanner to allow the user to enter a number
     * @return Integer sent by the user saved in a variable named, "userChoice"
     */
    public int pickDieToRoll(Scanner scanner)   { //Method checks what die they want to roll with rollsUsed
        if (!rollsUsed)   { //If they haven't, ask them which die they want to roll and save it as a variable
            System.out.print("What die would you like to roll: ");
            userChoice = scanner.nextInt();
        }
        else if (rollsUsed)   { //If they have, display error
            System.out.println("ERROR, try again."); System.out.println();
        }
        return userChoice; //Return saved variable used in YahtzeePlayer
    }

    /**
     * Emulates and creates the illusion of rolling by simply giving them a new die with a different number.
     * If they pick a valid option, it'll increment the stop condition until it hits 3. Once it hits 3, it'll prevent another roll.
     * If they pick an invalid option, it'll tell the user that it wasn't a valid die.
     * @author Alex Griep
     * @param Integer representing the die they picked sent by YahtzeePlayer
     */
    public void roll(int diePicked)   { //After the variable is tossed around in YahtzeePlayer, Method passes it in and checks it
        switch (diePicked)   {
            case 1: //If they picked die1...
                die1 = new Die(); //...give them a new die to emulate rolling...
                rollsDid += 1; //...increment the boolean end condition's counter by 1
                break;
            case 2:
                die2 = new Die(); //Ditto ^
                rollsDid += 1;
                break;
            case 3:
                die3 = new Die(); //I'm ditto too ^^
                rollsDid += 1;
                break;
            default:
                System.out.println("Not a valid die."); //If they picked anything other than a 1, 2, or a 3, display error message and prompt again
                roll(pickDieToRoll(scanner));
                break;
        }
        if (rollsDid >= 3)   { //Once the counter reaches 3, trip the boolean condition
            rollsUsed = true;
        }
    }

    /**
     * Looks at and determines if all the numbers of the dice are the same. If they are, the player scores a Yahtzee.
     * If not, 0 points are returned.
     * @author Alex Griep
     * @return Integer representing the total number of points accumulated throughout YahtzeePlayer
     */
    public int scoreYahtzee()   { //Method here scores a 'Yahtzee' score
        if ((die1.getValueOf() == die2.getValueOf()) && (die2.getValueOf() == die3.getValueOf()))   { //If all dice have the same value...
            finalScore += 50; //...add 50 points... 
            didYahtzee = true; //...trip boolean flag...
            turnEnded = true; //...end turn
        }
        else   { //Otherwise...
            finalScore += 0; //...add 0 points...
            didYahtzee = true; //...trip boolean flag...
            turnEnded = true; //end turn
        }
        return finalScore; //Return the score
    }

    /**
     * Looks at and determines if the numbers of the dice are in sequential order. If they are, the player scores a Straight.
     * If not, 0 points are returned.
     * @author Alex Griep
     * @return Integer representing the total number of points accumulated throughout YahtzeePlayer
     */
    public int scoreStraight()   {
        int lowestNum = Math.min(die1.getValueOf(), die2.getValueOf()); lowestNum = Math.min(lowestNum, die3.getValueOf()); //Finds the lowest num
        int highestNum = Math.max(die1.getValueOf(), die2.getValueOf()); highestNum = Math.max(highestNum, die3.getValueOf()); //Finds the highest num
        if (highestNum - lowestNum == 2)   { //Checks if they differ by 2..
            if (die1.getValueOf() != die2.getValueOf() && die1.getValueOf() != die3.getValueOf())   { //Checks if the first die is unique
                if (die2.getValueOf() != die3.getValueOf())   { //Checks if the second die is unique, therefore verifying the third die is unique
                    finalScore += 25;
                    didStraight = true;
                    turnEnded = true;
                }
            }
            else   {  //If the first die isn't unique (repeat numbers)
                finalScore += 0; //Add 0 and end the conditions
                didStraight = true;
                turnEnded = true;
            }
        }
        else   { //If they don't differ by 2..
            finalScore += 0; //Add 0 and end the conditions
            didStraight = true;
            turnEnded = true;
        }
        return finalScore; //Return the score
    }

    /**
     * Adds up the numbers of the dice and adds it to the players score throughout YahtzeePlayer.
     * @author Alex Griep
     * @return Integer representing the total number of points accumulated throughout YahtzeePlayer
     */
    public int scoreChance()   { //Method here scores a 'Chance' score
        didChance = true; //Trip the boolean flag...
        turnEnded = true; //...end the turn...
        return finalScore += die1.getValueOf() + die2.getValueOf() + die3.getValueOf(); //...and return the score tallying up the values of the dice
    }

    /**
     * Displays the score for the user.
     * @author Alex Griep
     * @return Integer representing the final number of points acuumulated throughout YahtzeePlayer
     */
    public int getScore()   {
        return finalScore; //Return the score added onto throughout the game
    }
}
