import java.util.Random;
/**
 * Class used to create an integer representation of a die
 *
 * @author Alex Griep
 * @version 12/15/2022
 */
public class Die
{
    private Random randGen = new Random();
    private int newDie;
    
    public Die()   {
        newDie = randGen.nextInt(6) + 1;
    }
    
    public int getValueOf()   {
        return newDie;
    }
}
