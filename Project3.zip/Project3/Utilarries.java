import java.util.Random;
/**
 * This program implements and demos a variety of coded methods working with Arrays
 *
 * @author Alex Griep
 * @version 12/01/2022
 */
public class Utilarries
{
    /**
     * Returns a string representation of the user's array. If the word isn't the last one in the array, it concatenates it with a comma and a space ("word, ").
     * Otherwise, it concatenates it without a comma or a space ("word") and encloses the string in two brackets ("[" , "]") to represent the array.
     * @param userString the string array given by the user.
     * @return a string representation of the string array given by the user.
     */
    public static String toString(String[] userString)   {
        String returnString = "["; //Establishes the beginning bracket

        for (int i = 0; i < userString.length; i++)   { //Incrementing through the length of the string
            if (i < userString.length - 1)   {  //If the increment is less than the end, concat with a comma
                returnString += userString[i] + ", ";
            }
            else   {  //Otherwise, concat normally
                returnString += userString[i];
            }
        }

        returnString += "]"; //Establishes the end bracket and returns it
        return returnString;
    }

    /**
     * Returns a string representation of the user's array. If the character isn't the last one in the array, it concatenates it with a comma and a space ("a, ").
     * Otherwise, it concatenates it without a comma or a space ("a") and encloses the string in two brackets ("[" , "]") to represent the array.
     * @param userCharArray the character array given by the user.
     * @return a string representation of the character array given by the user.
     */
    public static String toString(char[] userCharArray)   {
        String returnString = "["; //Establishes the beginning bracket

        for (int i = 0; i < userCharArray.length; i++)   { //Incrementing through the length of the string
            if (i < userCharArray.length - 1)   {  //If the increment is less than the end, concat with a comma
                returnString += userCharArray[i] + ", ";
            }
            else   {  //Otherwise, concat normally
                returnString += userCharArray[i];
            }
        }

        returnString += "]"; //Establishes the end bracket and returns it
        return returnString;
    }

    /**
     * Determines whether or not the integer array given by the user is in the correct order or not. (I.e. 1,2,3,4...). A boolean value of true is returned if it's in the correct order.
     * A boolean value of false is returned if it's not in the correct order.
     * @param userIntArray the integer array given by the user.
     * @return a boolean value determined by the order of the array.
     */
    public static boolean isSorted(int[] userIntArray)   {
        boolean result = true;
        int i = 0;

        while (i < userIntArray.length - 1 && result)   {
            if (userIntArray[i] > userIntArray[i + 1])   {
                result = false;
            }
            i++;
        }

        return result;
    }

    /**
     * Determines whether or not the string array given by the user is in the correct alphabetical order or not. (I.e "apple", "banana", "carrot").
     * A boolean value of true is returned if it is. A boolean value of false is returned if it isn't.
     * @param userStringArray the string array given by the user.
     * @return a boolean value determined by the alphabetical order of the array.
     */
    public static boolean isSorted(String[] userStringArray)   {
        boolean result = true;
        int i = 0;

        while (i < userStringArray.length - 1 && result)   {
            if (userStringArray[i].compareToIgnoreCase(userStringArray[i + 1]) > 0)   {
                result = false;
            }
            i++;
        }

        return result;
    }

    /**
     * Returns a substring representation of the given character array. It takes a start index (assuming the value is greater than 0) to determine where the substring will start...
     * ...and an end index (assuming the value is less than the length to determine where it will end.
     * @param userCharArray the character array given by the user
     * @param startIndx the integer value of where the user wants to start in the given array
     * @param endIndx the integer value of where the user wants to end in the given array
     * @return a string representation of the character array determined by the start and end indexes
     */
    public static char[] subArray(char[] userCharArray, int startIndx, int endIndx)   {
        char[] returnArray = new char[endIndx - startIndx]; //Establishes the return array and 'i' variable for while loop
        int i = 0;

        while (startIndx < endIndx)   {  //While the startIndx does not exceed the endIndx, returnArray = the charArray at startIndx
            returnArray[i] = userCharArray[startIndx];
            i++;
            startIndx++;
        }

        return returnArray;
    }

    /**
     * Returns a string representation of the given character array. It takes a start index to determine where the substring will start and will run to the end of the array.
     * @param userCharArray the character array given by the user
     * @param startIndx the integer value of where the user wants to start in the given array
     * @return a string representation of the character array determined by the start index, running until the end of the array
     */
    public static char[] subArray(char[] userCharArray, int startIndx)   {
        return Utilarries.subArray(userCharArray, startIndx, userCharArray.length); //Like subArray but with no endIndx
    }

    /**
     * Determines which of the two given arrays comes first alphabetically. If the first array comes first, it returns a negative integer. If the second array comes first, it returns a positive integer.
     * @param userCharArray1 the first character array given by the user to be compared
     * @param userCharArray2 the second character array given by the user to be compared
     * @return a negative or positive integer value determined by the method
     */
    public static int compare(char[] userCharArray1, char[] userCharArray2)   {
        int result = 0; //Initializes the result

        for (int i = 0; i < userCharArray1.length && i < userCharArray2.length; i++)   { //Increments through the arrays, as long as they remain shorter than the two arrays
            if (userCharArray1[i] > userCharArray2[i])   { //If the spot at 'i' for the first array is greater than the spot at 'i' for the second array , return 1
                result = 1;
            }
            else if (userCharArray1.length > userCharArray2.length || userCharArray2.length > userCharArray1.length)   { //If either length is longer than the other
                result = -1;
            }
            else if (userCharArray1[i] == userCharArray2[i])   {  //If length and sequence match
                result = 0;
            }
            else   { //...else return -1
                result = -1;
            }
        }

        return result;
    }

    /**
     * Determines whether or not the two given character array sequences are the same. Returns a boolean value of true if they are and a boolean value of false if they aren't.
     * @param userCharArray1 the first character array given by the user to be compared
     * @param userCharArray2 the second character array given by the user to be compared
     * @return a true or false boolean value determind by the method
     */
    public static boolean areEqual(char[] userCharArray1, char[] userCharArray2)   {
        boolean result = true; //Initializes the end result

        if ((userCharArray1.length > userCharArray2.length) || (userCharArray2.length > userCharArray1.length))   {
            result = false; //If either array is longer than the other, return false
        }
        else   { //Otherwise...
            for (int i = 0; i < userCharArray1.length && i < userCharArray2.length; i++)   { //Increment through the array(s)
                if (userCharArray1[i] != userCharArray2[i])   { //If the two arrays at 'i' aren't equal, return false
                    result = false;
                }
                else   { //If the two arrays are equal at 'i', return true
                    result = true;
                }
            }
        }

        return result;
    }

    /**
     * Determines where the a given character array sequence appears within another given character array sequence, returning -1 if it doesn't appear.
     * @param userCharArray1 the first character array given by the user to be compared
     * @param userCharArray2 the second character array given by the user to be compared
     * @return a positive integer determined by where the sequences occurs, or a negative integer if they don't occur
     */
    public static int locationIn(char[] userCharArray1, char[] userCharArray2)   {
        return Utilarries.locationIn(userCharArray1, userCharArray2, 0); //Calls locationIn below with startIndx at 0
    }

    /**
     * Determines where the a given character array sequence appears within another given character array sequence, at a certain starting index, returning -1 if it doesn't appear.
     * @param userCharArray1 the first character array given by the user to be compared
     * @param userCharArray2 the second character array given by the user to be compared
     * @param startIndx the integer value given by the user to determine where to start in the array
     * @return a positive integer determined by where the sequences occurs, or a negative integer if they don't occur
     */
    public static int locationIn(char[] userCharArray1, char[] userCharArray2, int startIndx)   {
        int result = -1;  //Initializes and establishes the end result, increment, and boolean condition
        int i = 0;
        boolean contCondition = true;

        if (userCharArray1.length > userCharArray2.length)   { //If the first array is longer than the second array, return -1
            result = -1;
        }
        else   {
            while ((i < userCharArray1.length) && (contCondition))   { //While the increment is less than the length of the first array and the boolean condition is true
                if (Integer.valueOf(userCharArray1[i]) == Integer.valueOf(userCharArray2[startIndx]))   { //If they're equal, return 'i' and end the loop
                    result = i;
                    contCondition = false;
                }
                else   { //Otherwise, return -1 and end the loop
                    result = -1;
                    contCondition = false;
                }
                if (Integer.valueOf(userCharArray1[i]) != Integer.valueOf(userCharArray2[startIndx]))   { //If charArray1 at 'i' doesn't match the startIndx for charArray2...
                    for (int j = startIndx; j < userCharArray2.length; j++)   {  //Increment through the array to find where it does occur
                        if (Integer.valueOf(userCharArray1[0]) == Integer.valueOf(userCharArray2[j]))   { //If a match is found, return the location and end the loop
                            result = j;
                            contCondition = false;
                        }
                    }
                }
                i++;
            }
        }

        return result;
    }

    /**
     * Determines whether or not the given character array sequences appears within another given character array sequence, returning a boolean value.
     * @param userCharArray1 the first character array given by the user to be compared
     * @param userCharArray2 the second character array given by the user to be compared
     * @return a boolean value determined by the method, true if found, false if not found
     */
    public static boolean appearsIn(char[] userCharArray1, char[] userCharArray2)   {
        boolean result = false; //Initializes the boolean result

        if (Utilarries.locationIn(userCharArray1, userCharArray2) >= 0)   { //If locationIn returns an integer greather than or equal to zero, that means it was found in the array
            result = true;
        }
        else   { //If locationIn doesn't return an integer greater than or equal to zero, that means it wasn't found in the array
            result = false;
        }

        return result;
    }

    /**
     * Randomly draws a specified amount of times (assuming the number passed in is between 0 and the length of the array)...
     * ...from a given array of strings, returning a string representation of drawn elements without any duplicates. If a duplicate draw occurs, it draws a different element instead of the duplicated one.
     * If there are multiple of the same string in the array, the method will draw the other multiplied string instead of the same one.
     * @param userArray the string array given by the user to be drawn from
     * @param arrayDraws the amount of times the user wishes to randomly draw from their string array
     * @return a string representation of the randomly drawn strings, avoiding duplicates unless more than one of a particular string is found in the array
     */
    public static String[] drawItems(String[] userArray, int arrayDraws)  {
        String[] returnArray = new String[arrayDraws];  //Establishes the return array, random generator, memNums to store random numbers generated, and initializes randNum with a random number
        Random rand = new Random();
        int randNum = rand.nextInt(userArray.length) + 1;
        int[] memNums = new int[arrayDraws];

        for (int i = 0; i < arrayDraws; i++)   { //As long as the increment is less than the amount of draws...
            boolean newDraw = true; 
            while (newDraw)   { //As long as it's a new draw...
                randNum = rand.nextInt(userArray.length) + 1; //Generate a new random number
                boolean noDupNum = true; //Establish a boolean showing that no duplicate number has been found
                int j = 0;
                while (j < memNums.length && noDupNum)   { //As long as 'j' is less than the memNum length and no duplicate number has been found...
                    if (randNum == memNums[j])   { //If a number matches in 'j'
                        noDupNum = false; //Duplicate number has been found so it jumps out
                    }
                    j++;
                }
                if (noDupNum)   { //Otherwise, if it remains true, jump out of newDraw
                    newDraw = false;
                }
            }
            memNums[i] = randNum; //Store randNum in memNums
            returnArray[i] = userArray[randNum - 1]; //Store userArray index of random number at 'i' into the return array
        }

        return returnArray;
    }

    /**
     * Randomizes the string array given by the user, avoiding duplicates or repeats unless multiple similar strings are present.
     * @param userArray the string array given by the user to be drawn from/randomized
     * @return a string representation of the randomized string
     */
    public static String[] drawItems(String[] userArray)   {
        return Utilarries.drawItems(userArray, userArray.length); //Calls drawItems above but sets the amount of draws to the entire string
    }

    public static void main(String[] args)   {
        //Testing the 1st toString method

        System.out.println("Testing the 1st 'toString' method: (String)");
        System.out.println("--------------------------------------");

        System.out.print("Printing a string representation of the string array {puppy, kitten, hamster}: ");
        String[] a1 = {"puppy", "kitten", "hamster"};
        System.out.println(Utilarries.toString(a1));

        System.out.print("Printing a string representation of the string array {fish, piglet, puppy, turtle}: ");
        String[] b1 = {"fish", "piglet", "puppy", "turtle"};
        System.out.println(Utilarries.toString(b1));

        System.out.print("Printing a string representation of the string array {Franz Kafka}: ");
        String[] myTest1 = {"Franz Kafka"};
        System.out.println(Utilarries.toString(myTest1));

        System.out.print("Printing a string representation of the string array {}: ");
        String[] c1 = new String[0];
        System.out.println(Utilarries.toString(c1)); System.out.println();

        //Testing the 2nd toString method

        System.out.println("Testing the 2nd 'toString' method: (String)");
        System.out.println("--------------------------------------");

        System.out.print("Printing a string representation of the char array {a, b, c}: ");
        char[] abc = {'a', 'b', 'c'};
        System.out.println(Utilarries.toString(abc));

        System.out.print("Printing a string representation of the char array {z}: " );
        char[] myTest2 = {'z'};
        System.out.println(Utilarries.toString(myTest2));

        System.out.print("Printing a string representation of the char array {}: ");
        char[] c2 = new char[0];
        System.out.println(Utilarries.toString(c2)); System.out.println();

        //Testing the 1st isSorted method

        System.out.println("Testing the 1st 'isSorted' method: (boolean)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the boolean result for {123, 23, 1}: ");
        int[] a2 = {123, 23, 1};
        System.out.println(Utilarries.isSorted(a2)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {-4, -3, -1, 1}: ");
        int[] b2 = {-4, -3, -1, 1};
        System.out.println(Utilarries.isSorted(b2)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {}: ");
        int[] c3 = new int[0];
        System.out.println(Utilarries.isSorted(c3)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {-9}: ");
        int[] myTest3 = {-9};
        System.out.println(Utilarries.isSorted(myTest3)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {1024, 2048, 1024, 2048}: ");
        int[] myTest4 = {1024, 2048, 1024, 2048};
        System.out.println(Utilarries.isSorted(myTest4)? "is sorted. (true)" : "is not sorted. (false)"); System.out.println();

        //Testing the 2nd isSorted method

        System.out.println("Testing the 2nd 'isSorted' method: (boolean)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the boolean result for {puppy, kitten, hamster}: ");
        String[] a3 = {"puppy", "kitten", "hamster"};
        System.out.println(Utilarries.isSorted(a3)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {kitten, piglet, puppy, turtle}: ");
        String[] b3 = {"kitten", "piglet", "puppy", "turtle"};
        System.out.println(Utilarries.isSorted(b3)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {}: ");
        String[] c4 = new String[0];
        System.out.println(Utilarries.isSorted(c4)? "is sorted. (true)" : "is not sorted. (false)");

        System.out.print("Printing the boolean result for {pineapple, pizza}: ");
        String[] myTest5 = {"pineapple", "pizza"};
        System.out.println(Utilarries.isSorted(myTest5)? "is sorted. (true)" : "is not sorted. (false)"); System.out.println();

        //Testing the 1st subArray method

        System.out.println("Testing the 1st 'subArray' method: (char)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the substring for {a, b, c, d, e, f, g} starting at index 1 and ending at index 4: ");
        char[] abcdefg1 = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
        System.out.println(Utilarries.toString(Utilarries.subArray(abcdefg1, 1, 4)));

        System.out.print("Printing the substring for {a, b, c, d, e, f, g} starting at index 3 and ending at index 5: ");
        System.out.println(Utilarries.toString(Utilarries.subArray(abcdefg1, 3, 5)));

        System.out.print("Printing the substring for {z} starting at index 0 and ending at index 0: ");
        char[] myTest6 = {'z'};
        System.out.println(Utilarries.toString(Utilarries.subArray(myTest6, 0, 0))); System.out.println();

        //Testing the 2nd subArray method

        System.out.println("Testing the 2nd 'subArray' method: (char)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the substring for {a, b, c, d, e, f, g} starting at index 5: ");
        char[] abcdefg2 = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
        System.out.println(Utilarries.toString(Utilarries.subArray(abcdefg2, 5)));

        System.out.print("Printing the substring for {t, u, v, w, x, y} starting at index 1: ");
        char[] myTestCase7 = {'t', 'u', 'v', 'w', 'x', 'y'};
        System.out.println(Utilarries.toString(Utilarries.subArray(myTestCase7, 1))); System.out.println();

        //Testing the compare method

        System.out.println("Testing the 'compare' method: (int)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the result of {a, b, c, d} compared to {e, f, g}: ");
        char[] abc1 = {'a', 'b', 'c'};
        char[] abcd1 = {'a', 'b', 'c', 'd'};
        char[] efg1 = {'e', 'f', 'g'};
        System.out.println(Utilarries.compare(abcd1, efg1));

        System.out.print("Printing the integer result of {e, f, g} compared to {a, b, c}: ");
        System.out.println(Utilarries.compare(efg1, abc1));

        System.out.print("Printing the integer result of {a, b, c} compared to {a, b, c, d}: ");
        System.out.println(Utilarries.compare(abc1, abcd1));

        System.out.print("Printing the integer result of {a, b, c} compared to {a, b, c}: ");
        System.out.println(Utilarries.compare(abc1, abc1)); System.out.println();

        //Testing the areEqual method

        System.out.println("Testing the 'areEqual' method: (boolean)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the boolean result for {a, b, c} compared with {a, b, c, d}: ");
        char[] abc2 = {'a', 'b', 'c'};
        char[] abcd2 = {'a', 'b', 'c', 'd'};
        char[] abc3 = {'a', 'b', 'c'};
        System.out.println(Utilarries.areEqual(abc2, abcd2)? "are equal. (true)" : "are not equal. (false)");

        System.out.print("Printing the boolean result for {a, b, c} compared with {a, b, c}: ");
        System.out.println(Utilarries.areEqual(abc2, abc3)? "are equal. (true)" : "are not equal. (false)"); 

        System.out.print("Printing the boolean result for {a, b, c, d} compared with {a, b, c}: ");
        System.out.println(Utilarries.areEqual(abcd2, abc2)? "are equal. (true)" : "are not equal. (false)"); System.out.println();

        //Testing the 1st locationIn method

        System.out.println("Testing the 1st 'locationIn' method: (int)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the integer result of the location of {a, b, c} in {a, b, c, d}: ");
        char[] abc4 = {'a', 'b', 'c'};
        char[] abcd3 = {'a', 'b', 'c', 'd'};
        char[] efg2 = {'e', 'f', 'g'};
        System.out.println(Utilarries.locationIn(abc4, abcd3));

        System.out.print("Printing the integer result of the location of {a, b, c, d} in {a, b, c}: ");
        System.out.println(Utilarries.locationIn(abcd3, abc4));

        System.out.print("Printing the integer result of the location of {e, f, g} in {a, b, c, d}: ");
        System.out.println(Utilarries.locationIn(efg2, abcd3));

        System.out.print("Printing the integer result of the location of {b, c} in {a, a, b, c, d, d}: ");
        char[] myTest8 = {'a', 'a', 'b', 'c', 'd', 'd'};
        char[] myTest9 = {'b', 'c'};
        System.out.println(Utilarries.locationIn(myTest9, myTest8)); System.out.println();

        //Testing the 2nd locationIn method

        System.out.println("Testing the 2nd 'locationIn' method: (int)");
        System.out.println("--------------------------------------");

        System.out.print("Printing the integer result of the location of {a, b} in {a, b, c, d} starting at index 1: ");
        char[] ab1 = {'a', 'b'};
        char[] abcd4 = {'a', 'b', 'c', 'd'};
        char[] abcdab1 = {'a', 'b', 'c', 'd', 'a', 'b'};
        System.out.println(Utilarries.locationIn(ab1, abcd4, 1));

        System.out.print("Printing the integer result of the location of {a, b} in {a, b, c, d, a, b} starting at index 1: ");
        System.out.println(Utilarries.locationIn(ab1, abcdab1, 1));

        System.out.print("Printing the integer result of the location of {a, b, d} in {a, b, c, d, a, b} starting at index 3: ");
        char[] myTest10 = {'a', 'b', 'd'};
        System.out.println(Utilarries.locationIn(myTest10, abcdab1, 3)); System.out.println();
        
        //Testing the appearsIn method
        
        System.out.println("Testing the 'appearsIn' method: (boolean)");
        System.out.println("--------------------------------------");
        
        System.out.print("Printing the boolean result of whether or not {a, b, c} appears in {a, b, c, d}: ");
        char[] abc5 = {'a', 'b', 'c'};
        char[] abcd5 = {'a', 'b', 'c', 'd'};
        char[] efg3 = {'e', 'f', 'g'};
        System.out.println(Utilarries.appearsIn(abc5, abcd5)? "does appear. (true)" : "does not appear. (false)" );
        
        System.out.print("Printing the boolean result of whether or not {a, b, c, d} appears in {a, b, c}: ");
        System.out.println(Utilarries.appearsIn(abcd5, abc5)? "does appear. (true)" : "does not appear. (false)" ); 
        
        System.out.print("Printing the boolean result of whether or not {e, f, g} appears in {a, b, c, d}: ");
        System.out.println(Utilarries.appearsIn(efg3, abcd5)? "does appear. (true)" : "does not appear. (false)"); System.out.println();
        
        //Testing the 1st drawItems method
        
        System.out.println("Testing the 1st 'drawItems' method: (String)");
        System.out.println("--------------------------------------");
        
        System.out.print("Drawing 2 items from {Kit Kat, m&ms, Nerds}: ");
        String[] candy1 = {"Kit Kat", "m&ms", "Nerds"};
        System.out.println(Utilarries.toString(Utilarries.drawItems(candy1, 2)));
        
        System.out.print("Drawing 3 items from {Kit Kat, m&ms, m&ms, Nerds}: ");
        String[] candy2 = {"Kit Kat", "m&ms", "m&ms", "Nerds"};
        System.out.println(Utilarries.toString(Utilarries.drawItems(candy2, 3)));
        
        System.out.print("Drawing 3 items from {Kit Kat, m&ms, m&ms, Nerds}: ");
        System.out.println(Utilarries.toString(Utilarries.drawItems(candy2, 3))); System.out.println();
        
        //Testing the 2nd drawItems method
        
        System.out.println("Testing the 2nd 'drawItems' method: (String)");
        System.out.println("--------------------------------------");
        
        System.out.print("Drawing all items from {Kit Kat, m&ms, Nerds}: ");
        String[] candy3 = {"Kit Kat", "m&ms", "Nerds"};
        System.out.println(Utilarries.toString(Utilarries.drawItems(candy3))); System.out.println();
    }
}
