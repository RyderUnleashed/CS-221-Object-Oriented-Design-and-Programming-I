import java.util.Scanner;
import java.util.Random;
/**
 * This program asks the user to input a minimum number and a maximum number
 * The program will then pick a random number between those two values and apporximates it's fibonacci number
 *
 * @author Alex Griep
 * @version 9/30/2022
 */
public class RandoFibo
{
    public static void main (String[] args)
    {
        Scanner input = new Scanner(System.in);
        int userMinNum;
        int userMaxNum;
        final double SQUARE_ROOT_FIVE = Math.sqrt(5);
        final double GOLDEN_RATIO = (1 + SQUARE_ROOT_FIVE) / 2;
        Random rand = new Random();
        
        //Program asks user for a minimum number
        System.out.print("Min N: ");
        userMinNum = input.nextInt();
        input.nextLine();
        
        //Program asks user for a maximum number
        System.out.print("Max N: ");
        userMaxNum = input.nextInt();
        input.nextLine();
        
        //Program picks a random number from the user's provided minimum and maximum values
        int randomNum = rand.nextInt(userMaxNum - userMinNum) + userMinNum + 1;
        System.out.println("Computing F" + randomNum);
        
        //Program calculates the N^th term FN using the formula
        int fiboNum = (int) Math.round((Math.pow(GOLDEN_RATIO, randomNum) - (Math.pow((1 - GOLDEN_RATIO), randomNum))) / SQUARE_ROOT_FIVE);
        
        //Program outputs number
        System.out.println("F" + randomNum + " is " + fiboNum);
    }
}
