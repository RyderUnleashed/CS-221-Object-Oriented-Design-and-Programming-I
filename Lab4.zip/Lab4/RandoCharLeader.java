import java.util.Random;
/**
 * This program generates random characters from their decimal value
 * The program then combines them in a "cheer" and outputs it
 *
 * @author Alex Griep
 * @version 9/30/22
 */
public class RandoCharLeader
{
    public static void main (String[] args)
    {
        Random rand = new Random();
        String stringChoices = ("@#$%^&*()");
        
        //Program generates a random uppercase letter and outputs it
        char upperChar = (char) ('A' + rand.nextInt(25));
        System.out.println("Give me a " + upperChar + "!");
        
        //Program generates a random lowercase letter and outputs it
        char lowerChar = (char) ('a' + rand.nextInt(25));
        System.out.println("Give me a " + lowerChar + "!");
        
        //Program generates a random special character and outputs it
        char specialChar = (stringChoices.charAt(rand.nextInt(stringChoices.length())));
        System.out.println("Give me a " + specialChar + "!");
        
        //Program combines the randomly generated characters and outputs it
        System.out.println("What's that spell?");
        System.out.println("" + upperChar + lowerChar + specialChar + " !");
    }
}
