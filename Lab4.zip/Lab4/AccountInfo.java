import java.util.Scanner;
/**
 * This program asks the user for their full name and CC#
 * 
 * It'll then provide the user a username consisting of their lastname and the
 * letter of their first name
 * 
 * It'll then output the credit card #, whilst masking the first 12 DIGITS regardless if the
 * user enters a '-' or not
 *
 * @author Alex Griep
 * @version 9/30/2022
 */
public class AccountInfo
{
    public static void main (String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        //Program asks the user for their full name
        System.out.print("Enter full name: ");
        String firstName = input.next();
        String lastName = input.next();
        input.nextLine();
        
        //Program asks the user for their credit card number (with or without '-')
        System.out.print("Enter credit card #: ");
        String creditNum = input.nextLine();
        
        //Program provides user with a username consisting of their
        //last name and first letter of their first name
        System.out.println("Welcome \"" + firstName + "\"" + "!");
        String lowFirstName = firstName.toLowerCase();
        String userName = lastName.toLowerCase() + lowFirstName.charAt(0);
        System.out.println("Your username is " + userName);
        
        //Program masks the first 12 digits of the user's CC# regardless of '-' and output it
        String maskedCCNum = ("************" + creditNum.substring(creditNum.length() - 4));
        System.out.println("Credit card #: " + maskedCCNum);
    }
}
