import java.util.Scanner;
/**
 * This program computes one's grade point average (GPA).
 *
 * @author Alex Griep
 * @version 11/9/2022
 */
public class Project2
{
    public static void main(String[] args)   {
        //Variables, Tools, Scanners, and other stuff
        Scanner input = new Scanner(System.in);
        String userGrade;
        double gradePoints = 0;
        double totalGradePoints = 0;
        int numCourses = 0;
        int numTerm = 0;
        int userCredits = 0;
        int termCredits = 0;
        int totalCredits = 0;

        //Program prompts user to enter the amount of courses they taken, outputting a summary if numCourses ==  0
        while (numCourses != -1)   {
            //Prompts the user to enter the amount of courses they took
            System.out.print("How many courses this term? (-1 if done): ");
            numCourses = input.nextInt();
            input.nextLine();

            //Program prompts the user to enter the grade and number of credits for each course
            //printing each input on a new line
            if ((numCourses != -1) && (numCourses != 0))   {    //Code here is to prevent any error prints
                System.out.println("Enter the grade and number of credits for each course: ");
            }
            for (int i = 1; i <= numCourses; i++)   {  
                userGrade = input.next();
                switch (userGrade)   {   //switch cases that increment values above and below based on what 'userGrade' is
                    case "A":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 4.00 * userCredits;
                        break;
                    case "A-":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 3.67 * userCredits;
                        break;
                    case "B+":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 3.33 * userCredits;
                        break;
                    case "B":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 3.00 * userCredits;
                        break;
                    case "B-":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 2.67 * userCredits;
                        break;
                    case "C+":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 2.33 * userCredits;
                        break;
                    case "C":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 2.00 * userCredits;
                        break;
                    case "C-":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 1.67 * userCredits;
                        break;
                    case "D+":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 1.33 * userCredits;
                        break;
                    case "D":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 1.00 * userCredits;
                        break;
                    case "D-":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 0.67 * userCredits;
                        break;
                    case "F":
                        userCredits = input.nextInt(); input.nextLine();
                        termCredits += userCredits;
                        gradePoints += 0.00 * userCredits;
                        break;
                    default:
                        System.out.println("Invalid letter grade(s). Enter them again as capital letters.");

                }
            }
            //final cumulative values are stored and calculated for future use
            totalGradePoints += gradePoints;
            totalCredits += termCredits;
            double termGPA = gradePoints / termCredits;
            double cumuGPA = totalGradePoints / totalCredits;

            if (termCredits == 0)   { //explictly checks for division by zero
                termGPA = 0;
            }

            //prints the summary of each loop iteration
            if (numCourses == -1)   {  //prints the final summary
                System.out.println(); System.out.println("Final Summary");
                System.out.println("-------------------------------------");
                System.out.printf("%-31s %d \n", "          Overall terms: ", numTerm);
                System.out.printf("%-31s %.2f \n", "     Total grade points: ", totalGradePoints);
                System.out.printf("%-31s %d \n","          Total credits: ", totalCredits);
                System.out.printf("%-31s %.2f \n", "         Cumulative GPA: ", cumuGPA);
                System.out.println();
                System.out.println("Done. Normal termination.");
            }
            else   {  //prints a summary for the user's term
                numTerm += 1;
                System.out.println("Summary for term " + numTerm);
                System.out.println("-------------------------------------");
                System.out.printf("%-31s %.2f \n", "  Term total grade points: ",gradePoints);
                System.out.printf("%-31s %d \n", "       Term total credits: ", termCredits);
                System.out.printf("%-31s %.2f \n", "                 Term GPA: ", termGPA);
                System.out.println();
            }

            //resets the values used for each loop iteration, storing them in the variables above
            gradePoints = 0;
            termCredits = 0;
        }
    }
}
