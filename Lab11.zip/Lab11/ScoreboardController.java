import java.util.Random;
import java.util.Scanner;
/**
 * Controller for a baseball scoreboard.
 *
 * @author Hannah and Alex Griep
 * @version Fall 2022
 */
public class ScoreboardController
{
    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        
        BaseballScoreboard scoreboard = new BaseballScoreboard();
        
        System.out.println(scoreboard.toString());
        System.out.println();
        System.out.println("SCOREBOARD CONTROLLER");
        System.out.println();
        
        boolean quit = false;
        while(!quit) {
            System.out.println(
              " 1: ON/OFF\n" +
              " 2: GUEST SCORE -1\n" +
              " 3: GUEST SCORE +1\n" +
              " 4: HOME SCORE -1\n" +
              " 5: HOME SCORE +1\n" +
              " 6: OUT +1\n" +
              " 7: CLEAR BALL & STRIKE\n" +
              " 8: BALL +1\n" +
              " 9: STRIKE +1\n" +
              "10: INNING +1\n" +
              "11: NEW GAME\n" +
              " 0: Quit\n"
            );
            System.out.print("Choice: ");
            int choice = in.nextInt();
            System.out.println();
            switch(choice) {
                case 1:
                    // switch on/off
                    System.out.println("ON/OFF");
                    scoreboard.switchOnOff(); 
                    break;
                case 2:
                    // guest score -1
                    System.out.println("GUEST SCORE -1");
                    scoreboard.guestScoreSubtractOne(); 
                    break;
                case 3:
                    // guest score +1
                    System.out.println("GUEST SCORE +1");
                    scoreboard.guestScoreAddOne();                    
                    break;
                case 4: 
                    // home score -1
                    System.out.println("HOME SCORE -1");
                    scoreboard.homeScoreSubtractOne(); 
                    break;
                case 5:
                    // home score +1
                    System.out.println("HOME SCORE +1");
                    scoreboard.homeScoreAddOne(); 
                    break;
                case 6:
                    // out +1
                    System.out.println("OUT +1");
                    scoreboard.addOut(); 
                    break;
                case 7:
                    // clear ball & strike
                    System.out.println("CLEAR BALL & STRIKE");
                    scoreboard.clearBallsAndStrikes(); 
                    break;
                case 8:
                    // ball +1
                    System.out.println("BALL +1");
                    scoreboard.addBall(); 
                    break;
                case 9:
                    // strike +1
                    System.out.println("STRIKE +1");
                    scoreboard.addStrike(); 
                    break;
                case 10:
                    // inning +1
                    System.out.println("INNING +1");
                    scoreboard.nextInning(); 
                    break;
                case 11:
                    // new game
                    System.out.println("NEW GAME");
                    scoreboard.newGame();                     
                    break;
                default:
                    // quiting the controller
                    System.out.println("Exiting...");
                    quit = true;
            }
            if(!quit) {
                System.out.println();
                System.out.println(scoreboard.toString());
                System.out.println();
            }
        }
    }
}
