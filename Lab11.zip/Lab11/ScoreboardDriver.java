
/**
 * This class is created to test the implemented methods in the BaseballScoreboard class
 *
 * @author Alex Griep
 * @version 12/7/2022
 */
public class ScoreboardDriver
{
    public static void main(String[] args) {
        //#TODO: create at least two instances of BaseballScoreboard
        //#TODO: demonstrate that your class is implemented correctly
        BaseballScoreboard testScoreboard1 = new BaseballScoreboard();
        BaseballScoreboard testScoreboard2 = new BaseballScoreboard(12, 18, 9);

        //# (call all of your methods (multiple times each) 
        //#  and show that what you expect to happen is what actually happens;
        //#  alternate which instance you're currently testing to demonstrate
        //#  their independence)
        System.out.println("Test scoreboard 1: Turning board on and adding two strikes");
        testScoreboard1.switchOnOff(); //Testing if board turns on
        testScoreboard1.addStrike(); testScoreboard1.addStrike(); //Testing if add strikes works properly
        System.out.println(testScoreboard1.toString()); System.out.println(); //Testing toString

        System.out.println("Test scoreboard 2: Printing the board and adding two points to the guest team before turning on");
        testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne(); //Testing if we can change the game before the board is turned on
        System.out.println(testScoreboard2.toString()); System.out.println();

        System.out.println("Test scoreboard 1: Adding three points to the guest score and another strike and an out");
        testScoreboard1.guestScoreAddOne(); testScoreboard1.guestScoreAddOne(); testScoreboard1.guestScoreAddOne(); testScoreboard1.addStrike(); testScoreboard1.addOut(); //Testing strikes, outs, and adding points
        System.out.println(testScoreboard1.toString()); System.out.println();

        System.out.println("Test scoreboard 2: Turning on the board with the pre-entered parameters");
        testScoreboard2.switchOnOff(); //Testing turning on the board with pre-initialized values
        System.out.println(testScoreboard2.toString()); System.out.println();
        
        System.out.println("Test scoreboard 1: Adding two more outs to the guest, two points to the home team and one strike");
        testScoreboard1.addOut(); testScoreboard1.addOut(); testScoreboard1.homeScoreAddOne(); testScoreboard1.homeScoreAddOne(); testScoreboard1.addStrike(); 
        System.out.println(testScoreboard1.toString()); System.out.println();
        
        System.out.println("Test scoreboard 2: Adding 2 outs, 2 balls, and 1 strike");
        testScoreboard2.addOut(); testScoreboard2.addOut(); testScoreboard2.addBall(); testScoreboard2.addBall(); testScoreboard2.addStrike(); //Testing adding balls
        System.out.println(testScoreboard2.toString()); System.out.println();
        
        System.out.println("Test scoreboard 1: Subtracting three points from home team and changing the inning");
        testScoreboard1.homeScoreSubtractOne(); testScoreboard1.homeScoreSubtractOne(); testScoreboard1.homeScoreSubtractOne(); testScoreboard1.nextInning(); //Testing subtracting scores and changing innings
        System.out.println(testScoreboard1.toString()); System.out.println();
        
        System.out.println("Test scoreboard 2: Clearing balls and strikes");
        testScoreboard2.clearBallsAndStrikes(); //Testing clearing balls and strikes work
        System.out.println(testScoreboard2.toString()); System.out.println();
        
        System.out.println("Test scoreboard 1: Operator error. Starting new game...");
        testScoreboard1.newGame(); //Testing if starting a new game works
        System.out.println(testScoreboard1.toString()); System.out.println();
        
        System.out.println("Test scoreboard 2: Adding six points, another out, and changing the inning (tie game)");
        testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne(); testScoreboard2.guestScoreAddOne();
        testScoreboard2.addOut(); testScoreboard2.nextInning(); //Testing if innnings overlap due to a tie game
        System.out.println(testScoreboard2.toString()); System.out.println();
        
        System.out.println("Test scoreboard 1: Turning board off.");
        testScoreboard1.switchOnOff(); //Testing if board turns off
        System.out.println(testScoreboard1.toString()); System.out.println();
    }
}
