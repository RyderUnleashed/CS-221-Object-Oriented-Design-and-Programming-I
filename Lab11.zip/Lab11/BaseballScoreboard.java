
/**
 * BaseballScoreboard is a class that implements an object and the below methods to represent the varying states for the scoreboard of a baseball game.
 *
 * @author Alex Griep
 * @version 12/7/2022
 */
public class BaseballScoreboard
{
    //#TODO Instance Variables
    private boolean boardOnOff = false;
    private int guestScore;
    private int homeScore;
    private int numOuts;
    private int numBalls;
    private int numStrikes;
    private int numInnings;

    //#TODO Constructors
    /**
     * Default constructor initializing BaseBallScoreboard with all initial values set to 0.
     */
    public BaseballScoreboard()   {
        guestScore = 0;
        homeScore = 0;
        numOuts = 0;
        numBalls = 0;
        numStrikes = 0;
        numInnings = 1;
    }

    /**
     * Constructor initializing BaseballScoreboard with this.guestScore to guestScore, this.homeScore to homeScore, and numInnings to inning.
     * @param guestScore pre-defined score for the away team
     * @param homeScore pre-defined score for the home team
     * @param inning pre-defined inning for the ongoing game
     */
    public BaseballScoreboard(int guestScore, int homeScore, int inning)   {
        this.guestScore = guestScore;
        this.homeScore = homeScore;
        numOuts = 0;
        numBalls = 0;
        numStrikes = 0;
        numInnings = inning;
    }

    //#TODO Instance Methods
    /**
     * If the scoreboard is currently on, it should be turned off.
     * If the scoreboard is currently off, it should be turned on with its
     * values initialized to the values of a new game.
     */
    public void switchOnOff()   {
        if (boardOnOff == false)   {
            boardOnOff = true;
        }
        else if (boardOnOff == true)   {
            boardOnOff = false;
            newGame();
        }
    }

    /**
     * Reduces the guest's score by one point, if it wouldn't cause the score
     * to be negative (a negative score is not allowed/possible).
     */
    public void guestScoreSubtractOne()   {
        if (boardOnOff)   {
            if (guestScore != 0)   {
                guestScore -= 1;
            }
            else   {
                guestScore = 0;
            }
        }
    }

    /**
     * Increases the guest's score by one point. If the score was 99, it will
     * wrap around to 0 (only 2 digits are allowed/possible).
     */
    public void guestScoreAddOne()   {
        if (boardOnOff)   {
            if (guestScore != 99)   {
                guestScore += 1;
            }
            else   {
                guestScore = 0;
            }
        }
    }

    /**
     * Reduces the home score by one point, if it wouldn't cause the score to
     * be negative (a negative score is not allowed/possible).
     */
    public void homeScoreSubtractOne()   {
        if (boardOnOff)   {
            if (homeScore != 0)   {
                homeScore -= 1;
            }
            else   {
                homeScore = 0;
            }
        }
    }

    /**
     * Increases the home score by one point. If the score was 99, it will
     * wrap around to 0 (only 2 digits are allowed/possible).
     */
    public void homeScoreAddOne()   {
        if (boardOnOff)   {
            if (homeScore != 99)   {
                homeScore += 1;
            }
            else   {
                homeScore = 0;
            }
        }
    }

    /**
     * Increases the number of outs. If it's a third out, the outs are 
     * wiped to zero.
     */
    public void addOut()   {
        if (boardOnOff)   {
            if (numOuts < 2)   {
                numOuts += 1;
            }
            else if (numOuts == 2)   {
                numOuts = 0;
            }
        }
    }

    /**
     * Clears all balls and strikes from the board.
     */
    public void clearBallsAndStrikes()   {
        if (boardOnOff)   {
            numBalls = 0;
            numStrikes = 0;
        }
    }

    /**
     * Increases the number of balls. If it's a fourth ball, the balls
     * are wiped to zero.
     */
    public void addBall()   {
        if (boardOnOff)   {
            if (numBalls < 3)   {
                numBalls += 1;
            }
            else if (numBalls == 3)   {
                numBalls = 0;
            }
        }
    }

    /**
     * Increases the number of strikes. If it's a third strike, the strikes
     * are wiped to zero.
     */
    public void addStrike()   {
        if (boardOnOff)   {
            if (numStrikes < 2)   {
                numStrikes += 1;
            }
            else if (numStrikes == 2)   {
                numStrikes = 0;
            }
        }
    }

    /**
     * Increases the inning. If it was the 9th inning, it will wrap around to
     * 0 (only 1 digit is allowed/possible).
     */
    public void nextInning()   {
        if (boardOnOff)   {
            if (numInnings < 9)   {
                numInnings += 1;
            }
            else   {
                numInnings = 0;
            }
        }
    }

    /**
     * Sets all values of the scoreboard for a new game: both scores set to 
     * zero, inning set to 1, balls, strikes, and outs set to zero.
     */
    public void newGame()   {
        guestScore = 0;
        homeScore = 0;
        numInnings = 1;
        numBalls = 0;
        numStrikes = 0;
        numOuts = 0;
    }

    // Note that the <pre> text in the JavaDoc below is there intentionally
    // to preserve newlines and whitespace when the JavaDoc is displayed
    // to users in the Documentation view or auto-completion view.
    // The JavaDoc here is complete, but 
    //# the method implementation below is started, but not complete 
    //# (see TODOs in the method below)
    /**
     * <pre>
     * Returns a multi-line String representation of a scoreboard 
     * that is on in the format:
     * -----------------------
     * | GUEST  INNING  HOME |
     * |    0      1      0  |
     * |                     |
     * |  BALL  STRIKE  OUT  |
     * |                     |
     * -----------------------
     * The guest team’s score is displayed, followed by the inning, 
     * followed by the home team’s score. Next, the current number of 
     * balls, strikes and outs are displayed using X’s 
     * where the number of X’s indicates the number of each 
     * there currently are of balls, strikes and outs.
     * 
     * For example, a game that is in the 9th inning 
     * with a guest score of 14, home score of 11, 
     * 3 balls, 2 strikes and 2 outs would return the following String: 
     * -----------------------
     * | GUEST  INNING  HOME |
     * |   14      9     11  |
     * |                     |
     * |  BALL  STRIKE  OUT  |
     * | X X X   X X    X X  |
     * -----------------------
     * 
     * If the scoreboard is currently off, 
     * no numbers or Xs should be displayed:
     * -----------------------
     * | GUEST  INNING  HOME |
     * |                     |
     * |                     |
     * |  BALL  STRIKE  OUT  |
     * |                     |
     * -----------------------
     * </pre>
     * @return String representation of the scoreboard
     */
    public String toString() {
        String scoreboard = "";
        scoreboard += "-----------------------\n";
        scoreboard += "| GUEST  INNING  HOME |\n";
        //#TODO if the game is on, 
        //# include the current scores and inning, 
        //# otherwise include no values
        if(boardOnOff == true) {    
            scoreboard += String.format(
                "|   %2d      %d     %2d  |\n", 
                guestScore, 
                numInnings, 
                homeScore
            );
        } else {
            scoreboard += "|                     |\n";
        }
        scoreboard += "|                     |\n";
        scoreboard += "|  BALL  STRIKE  OUT  |\n";
        //#TODO if the game is on, 
        //#include Xs for the number of balls, strikes and outs
        //#otherwise include no Xs
        if (boardOnOff == true)   {
            scoreboard += String.format(
                "|%-6s  %-4s   %-4s  |\n",
                " X".repeat(numBalls),
                " X".repeat(numStrikes),
                " X".repeat(numOuts)
            );
        } else {
            scoreboard += "|                     |\n";
        }
        //scoreboard += "|                     |\n";
        scoreboard += "-----------------------";
        return scoreboard;
    }
}
