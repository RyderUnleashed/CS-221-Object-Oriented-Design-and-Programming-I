import java.util.Scanner;
/**
 * This program detects which letter occurs the most throughout a given phrase of text.
 *
 * @author Alex Griep
 * @version 11/10/2022
 */
public class CountMostOccurringLetter
{
    public static void main(String[] args)   {
        //scanner, variables, and other stuff
        Scanner input = new Scanner(System.in);
        String userStr;
        int charOccurs = 0;
        int maxValue = 0;
        int i = 0;
        int j = 0;

        System.out.print("Text: "); //Program prompts the user to enter a string of text
        userStr = input.nextLine();
        char stringLtr = userStr.charAt(i); //char variable is initialized

        for (i = 0; i <= userStr.length() - 1; i++)   {
            for (j = 0; j <= userStr.length() - 1; j++)   {
                if (userStr.charAt(i) == userStr.charAt(j))   {  //if letter at i matches letter at j, increment charOccurs
                    charOccurs += 1;
                }
            }
            if (charOccurs > maxValue)   { // if charOccurs is greater than the maxValue (initial value is 0), charOccurs becomes the maxValue
                maxValue = charOccurs;
                stringLtr = userStr.charAt(i);
            }
            charOccurs = 0;  //resets charOccurs for outer loop iteration
        }
        System.out.println("" + stringLtr + " occurs the most! (" + maxValue + " times)");  //prints result
    }
}
