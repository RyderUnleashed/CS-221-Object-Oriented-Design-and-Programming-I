import java.util.Scanner;
/**
 * This program prompts the user to enter in how much candy they've received and what they all got. It'll then print a variety of combinations for them to pick from.
 *
 * @author Alex Griep
 * @version 11/10/2022
 */
public class HalloweenCandy
{
    public static void main(String[] args)   {
        //Scanners, variables, and other stuff
        Scanner input = new Scanner(System.in);
        int numCandies;
        int i;
        int j;
        
        //program should prompt user to enter how much candies they received
        System.out.print("How many candies? ");
        numCandies = input.nextInt(); input.nextLine();
        String[] halloCandy = new String[numCandies];
        
        //program should then prompt to enter the candies, printing each on a new line while incrementing throught the array
        System.out.println("Enter your candies!");
        for (i = 0; i < halloCandy.length; i++)   {
            System.out.print("Candy " + (i + 1) + ": ");
            halloCandy[i] = input.nextLine();
        }
        
        //program should then output the results of the combinations
        System.out.println(); System.out.println("Your possibilities to enjoy include: ");
        for (i = 0; i < halloCandy.length; i++)   {
            for (j = 1; j < halloCandy.length; j++)   {
                if ((halloCandy[i] != halloCandy[j]) && (j > i))   {   //condition states that if the candies do not match and the second value is greater, then it can print
                    System.out.printf("%12s and %s \n", halloCandy[i], halloCandy[j]);
                }
            }
        }
    }
}
