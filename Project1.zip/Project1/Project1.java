import java.util.Scanner;
/**
 * This program prompts the user to choose a format for displaying age and weight
 * of a newborn baby to determine if they're healthy or not.
 *
 * @author Alex Griep
 * @version 10/19/2022
 */
public class Project1
{
    public static void main (String[] args)   {
        Scanner input = new Scanner(System.in);
        int userChoice;
        double infantWeight = 0;
        double infantAge = 0;
        final double INFANT_CALC1;
        final double INFANT_CALC2;
        
        //Program greets user and asks them which method they'd prefer
        System.out.println("Welcome to the Infant Weight Evaluator!");
        System.out.println("Which units would you like to use to enter in the age and weight?");
        System.out.println("1: months and kg");
        System.out.println("2: years and kg");
        System.out.println("3: months and pounds");
        System.out.println("4: years and pounds");
        
        //User enters the choice and program does the calculations based on their choice
        System.out.print("Choice #: ");
        userChoice = input.nextInt();
        input.nextLine();
        INFANT_CALC1 = ((infantAge / 3) + 2);
        INFANT_CALC2 = (((5 * infantAge) / 12) + 5);
        switch (userChoice)   {
            //case 1 for months and kg
            case 1:
                System.out.print("Enter the age in months: ");
                infantAge = input.nextDouble();
                input.nextLine();
                    if (infantAge < 0)   {
                        System.out.println("Error, too young.");
                    }
                    else if (infantAge > 24)   {
                        System.out.println("Error, too old.");
                    }
                    else   {
                        System.out.print("Enter the weight in kg: ");
                        infantWeight = input.nextDouble();
                        input.nextLine();
                            if ((infantWeight < 2) || (infantWeight > 15))   {
                                System.out.println("Error, weight is invalid.");
                            }
                            else if ((infantWeight >= INFANT_CALC1) || (infantWeight <= INFANT_CALC2))   {
                                System.out.println();
                                System.out.println("Age/weight is in the healthy range!");
                            }
                            else   {
                                System.out.println();
                                System.out.println("Age/weight is not in the healthy range.");
                            }
                    }
                break;
                
            //case 2 for years and kg
            case 2:
                System.out.print("Enter the age in years: ");
                infantAge = input.nextDouble() * 12;
                input.nextLine();
                    if (infantAge < 0)   {
                        System.out.println("Error, too young.");
                    }
                    else if (infantAge > 24)   {
                        System.out.println("Error, too old.");
                    }
                    else   {
                        System.out.print("Enter the weight in kg: ");
                        infantWeight = input.nextDouble();
                        input.nextLine();
                            if ((infantWeight < 2) || (infantWeight > 15))   {
                                System.out.println("Error, weight is invalid.");
                            }
                            else if((infantWeight >= INFANT_CALC1) || (infantWeight <= INFANT_CALC2))   {
                                System.out.println();
                                System.out.println("Age/weight is in the healthy range!");
                            }
                            else   {
                                System.out.println();
                                System.out.println("Age/weight is not in the healthy range.");
                            }
                    }
                break;
                
            //case 3 for months and lbs
            case 3:
                System.out.print("Enter the age in months: ");
                infantAge = input.nextDouble();
                input.nextLine();
                    if (infantAge < 0)   {
                        System.out.println("Error, too young.");
                    }
                    else if (infantAge > 24)   {
                        System.out.println("Error, too old.");
                    }
                    else   {
                        System.out.print("Enter the weight in lbs: ");
                        infantWeight = input.nextDouble() / 2.2046;
                        input.nextLine();
                            if ((infantWeight < 2) || (infantWeight > 15))   {
                                System.out.println("Error, weight is invalid.");
                            }
                            else if ((infantWeight >= INFANT_CALC1) || (infantWeight <= INFANT_CALC2))   {
                                System.out.println();
                                System.out.println("Age/weight is in the healthy range!");
                            }
                            else   {
                                System.out.println();
                                System.out.println("Age/weight is not in the healthy range.");
                            }
                    }
                break;
            
            //case 4 for years and lbs
            case 4:
                System.out.print("Enter the age in years: ");
                infantAge = input.nextDouble() * 12;
                input.nextLine();
                    if (infantAge < 0)   {
                        System.out.println("Error, too young.");
                    }
                    else if (infantAge > 24)   {
                        System.out.println("Error, too old.");
                    }
                    else   {
                        System.out.print("Enter the weight in lbs: ");
                        infantWeight = input.nextDouble() / 2.2046;
                        input.nextLine();
                            if ((infantWeight < 2) || (infantWeight > 15))   {
                                System.out.println("Error, weight is invalid.");
                            }
                            else if ((infantWeight >= INFANT_CALC1) || (infantWeight <= INFANT_CALC2))   {
                                System.out.println();
                                System.out.println("Age/weight is in the healthy range!");
                            }
                            else   {
                                System.out.println();
                                System.out.println("Age/weight is not in the healthy range.");
                            }
                    }
                break;
                
            //default case for if the user fails to pick the above four
            default:
                System.out.println("Error, invalid choice.");
                break;
        }
    }
}
