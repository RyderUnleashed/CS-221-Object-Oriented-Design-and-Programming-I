import java.util.Scanner;
/**
 * This program allows the user to input two RGB values and a mixing ratio (percent)
 * and displays the resulting color as an RGB value
 *
 * @author Alex Griep
 * @version 9/29/2022
 */
public class ColorMixer
{
    public static void main (String[] args) 
    {
        Scanner input = new Scanner(System.in);
        int userColor1;
        int userColor2;
        double userMixRatio;
        
        //Program asks for user input for Color 1
        System.out.print("Color 1: ");
        userColor1 = input.nextInt();
        input.nextLine();
        
        //Program asks for user input for Color 2
        System.out.print("Color 2: ");
        userColor2 = input.nextInt();
        input.nextLine();
        
        //Program asks for user input for Mixing Ratio
        System.out.print("Mixing Ratio (for Color 1 /100): ");
        userMixRatio = input.nextInt();
        input.nextLine();
        int userMixRatio2 = 100 - (int) userMixRatio;
        
        //Program begins to apply the formula for the user's R, G, and B values
        System.out.println("Mixing Color 1 with Color 2 at ratio " + (int) userMixRatio + "/" + userMixRatio2 + " yields color: ");
        
        //Calculations for user's R value
        int userRed1 = (userColor1 / 1000000);
        int userRed2 = (userColor2 / 1000000);
        int finalRed = (int)(((userMixRatio / 100) * userRed1) + (int)((1 - (userMixRatio / 100)) * userRed2));
        
        //Calculations for user's G value
        int userGreen1 = (userColor1 / 1000) % 1000;
        int userGreen2 = (userColor2 / 1000) % 1000;
        int finalGreen = (int)(((userMixRatio / 100) * userGreen1) + (int)((1 - (userMixRatio / 100)) * userGreen2));
        
        //Calculations for user's B Value
        int userBlue1 = (userColor1 % 1000);
        int userBlue2 = (userColor2 % 1000);
        int finalBlue = (int)(((userMixRatio / 100) * userBlue1) + (int)((1 - (userMixRatio / 100)) * userBlue2));
        
        //Program outputs final color's R, G, and B values
        System.out.println("R: " + finalRed);
        System.out.println("G: " + finalGreen);
        System.out.println("B: " + finalBlue);
    }
}
