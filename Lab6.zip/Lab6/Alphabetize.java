import java.util.Scanner;
/**
 * This program asks the user to input three words and arranges them in alphabetical order
 *
 * @author Alex Griep
 * @version 10/18/2022
 */
public class Alphabetize
{
    public static void main (String[] args)   {
        Scanner input = new Scanner(System.in);
        
        //Program asks user for three words
        System.out.print("Enter three words: ");
        String firstString = input.next();
        String secondString = input.next();
        String thirdString = input.next();
        input.nextLine();
        
        //Program compares and prints the three words in alphabetical order
        if ((firstString.compareToIgnoreCase(secondString) < 0) && (thirdString.compareToIgnoreCase(firstString) > 0))   {
            if (secondString.compareToIgnoreCase(thirdString) < 0)   {
                System.out.println("In alphabetical order: " + firstString + " " + secondString + " " + thirdString);
            }
            else if (secondString.compareToIgnoreCase(thirdString) > 0)   {
                System.out.println("In alphabetical order: " + firstString + " " + thirdString + " " + secondString);
            }
        }
        else if ((secondString.compareToIgnoreCase(firstString) < 0) && (thirdString.compareToIgnoreCase(secondString) > 0))  {
            if (firstString.compareToIgnoreCase(thirdString) < 0)   {
                System.out.println("In alphabetical order: " + secondString + " " + firstString + " " + thirdString);
            }
            else if (firstString.compareToIgnoreCase(thirdString) > 0)   {
                System.out.println("In alphabetical order: " + secondString + " " + thirdString + " " + firstString);
            }
        }
        else if ((thirdString.compareToIgnoreCase(firstString) < 0) && (secondString.compareToIgnoreCase(thirdString) > 0))   {
            if (firstString.compareToIgnoreCase(secondString) < 0)   {
                System.out.println("In alphabetical order: " + thirdString + " " + firstString + " " + secondString);
            }
            else if (firstString.compareToIgnoreCase(secondString) > 0)   {
                System.out.println("In alphabetical order: " + thirdString + " " + secondString + " " + firstString);
            }
        }
    }
}
