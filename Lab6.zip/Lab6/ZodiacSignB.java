import java.util.Scanner;
/**
 * This program asks the user for a birth month and day and figures out what their zodiac sign is by using switch statements
 *
 * @author Alex Griep
 * @version 10/18/2022
 */
public class ZodiacSignB
{
    public static void main (String[] args)   {
        Scanner input = new Scanner(System.in);
        
        //Program asks user input for their birthday month and day
        System.out.print("Enter birth month and day: ");
        String userBirth = input.next();
        int birthDay = input.nextInt();
        input.nextLine();
        String zodiacSign = " ";
        
        //Program runs through switch cases to figure out what their zodiac sign is
        switch (userBirth)   {
            case "January":
                zodiacSign = (birthDay >= 20) ? "Aquarius" : "Capricornus";
                break;
            case "February":
                zodiacSign = (birthDay <= 18) ? "Aquarius" : "Pisces";
                break;
            case "March":
                zodiacSign = (birthDay >= 20) ? "Pisces" : "Aries";
                break;
            case "April":
                zodiacSign = (birthDay <= 19) ? "Aries" : "Taurus";
                break;
            case "May":
                zodiacSign = (birthDay <= 20) ? "Taurus" : "Gemini";
                break;
            case "June":
                zodiacSign = (birthDay <= 21) ? "Gemini" : "Cancer";
                break;
            case "July":
                zodiacSign = (birthDay <= 22) ? "Cancer" : "Leo";
                break;
            case "August":
                zodiacSign = (birthDay <= 22) ? "Leo" : "Virgo";
                break;
            case "September":
                zodiacSign = (birthDay <= 22) ? "Virgo" : "Libra";
                break;
            case "October":
                zodiacSign = (birthDay <= 23) ? "Libra" : "Scorpius";
                break;
            case "November":
                zodiacSign = (birthDay <= 21) ? "Scorpius" : "Sagittarius";
                break;
            case "December":
                zodiacSign = (birthDay <= 21) ? "Sagittarius" : "Capricornus";
                break;
            default:
                return;
        }
        
        //Program outputs user's zodiac sign
        System.out.println("You are a " + zodiacSign + "!");
    }
}
