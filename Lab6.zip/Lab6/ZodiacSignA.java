import java.util.Scanner;
/**
 * This program simply asks the user for their birth month and day and tells them what their
 * zodiac sign is.
 *
 * @author Alex Griep
 * @version 10/14/2022
 */
public class ZodiacSignA
{
    public static void main(String[] args)   {
        Scanner input = new Scanner(System.in);
        String userBirth;
        int birthDay;
        
        //Program asks the user for their birth month and day
        System.out.print("Enter birth month and day: ");
        userBirth = input.next();
        birthDay = input.nextInt();
        input.nextLine();
        
        //Program figures out what their zodiac sign is using if statements
        if (userBirth.equals("January"))   {
            if (birthDay >= 20)   {
                System.out.println("You are a Aquarius!");
            }
            else   {
                System.out.println("You are a Capricornus!");
            }
        }
        else if (userBirth.equals("February"))   {
            if (birthDay <= 18)   {
                System.out.println("You are a Aquarius!");
            }
            else   {
                System.out.println("You are a Pisces!");
            }
        }
        else if (userBirth.equals("March"))   {
            if (birthDay <= 20)   {
                System.out.println("You are a Pisces!");
            }
            else   {
                System.out.println("You are a Aries!");
            }
        }
        else if (userBirth.equals("April"))   {
            if (birthDay <= 19)   {
                System.out.println("You are a Aries!");
            }
            else   {
                System.out.println("You are a Taurus!");
            }
        }
        else if (userBirth.equals("May"))   {
            if (birthDay <= 20)   {
                System.out.println("You are a Taurus!");
            }
            else   {
                System.out.println("You are a Gemini!");
            }
        }
        else if (userBirth.equals("June"))   {
            if (birthDay <= 21)   {
                System.out.println("You are a Gemini!");
            }
            else   {
                System.out.println("You are a Cancer!");
            }
        }
        else if (userBirth.equals("July"))   {
            if (birthDay <= 22)   {
                System.out.println("You are a Cancer!");
            }
            else   {
                System.out.println("You are a Leo!");
            }
        }
        else if (userBirth.equals("August"))   {
            if (birthDay <= 22)   {
                System.out.println("You are a Leo!");
            }
            else   {
                System.out.println("You are a Virgo!");
            }
        }
        else if (userBirth.equals("September"))   {
            if (birthDay <= 22)   {
                System.out.println("You are a Virgo!");
            }
            else   {
                System.out.println("You are a Libra!");
            }
        }
        else if (userBirth.equals("October"))   {
            if (birthDay <= 23)   {
                System.out.println("You are a Libra!");
            }
            else   {
                System.out.println("You are a Scorpius!");
            }
        }
        else if (userBirth.equals("November"))  {
            if (birthDay <= 21)   {
                System.out.println("You are a Scorpius!");
            }
            else   {
                System.out.println("You are a Sagittarius!");
            }
        }
        else if (userBirth.equals("December"))   {
            if (birthDay <= 21)   {
                System.out.println("You are a Sagittarius!");
            }
            else   {
                System.out.println("You are a Capricornus!");
            }
        }
    }
}
