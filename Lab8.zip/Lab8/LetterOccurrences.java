import java.util.Scanner;
/**
 * This program prompts the user to enter a word of their choosing and to pick a letter. The program will then count how many times the letter occurs.
 *
 * @author Alex Griep
 * @version 10/28/2022
 */
public class LetterOccurrences
{
    public static void main(String[] args)   {
        Scanner input = new Scanner(System.in);
        String userString1;
        String userString2;
        char userLetter;
        int charOccurs = 0;
        
        System.out.print("Text: ");
        userString1 = input.nextLine();
        userString2 = userString1.toLowerCase();
        System.out.print("Letter: ");
        userLetter = input.next().charAt(0);
        
        for (int i = 0; i <= userString2.length() - 1; i++)   {
            if (userString2.charAt(i) == userLetter)   {
                charOccurs += 1;
            }
        }
        System.out.println();
        System.out.print("\'" + userLetter + "\'" + " occurs " + charOccurs + " time(s)");
    }
}
