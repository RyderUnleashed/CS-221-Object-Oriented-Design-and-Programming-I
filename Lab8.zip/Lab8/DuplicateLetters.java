import java.util.Scanner;
/**
 * This program prompts the user to enter a string and it'll output whether or not the string has duplicate letters in it or not.
 *
 * @author Alex Griep
 * @version 10/31/2022
 */
public class DuplicateLetters
{
    public static void main(String[] args)   {
        //Variables and other stuff
        Scanner input = new Scanner(System.in);
        String userString1;
        System.out.print("Text: ");
        
        //converting whatever the user enters to lower case to avoid error
        userString1 = input.nextLine();
        String userString2 = userString1.toLowerCase();
        
        //boolean flag set to false, loop below will trip if otherwise
        boolean hasDuplicate = false;
        
        
        //for loop with boolean flag to detect whether a duplicate letter is present or not
        for (int i = 0; i <= userString2.length() - 1; i++)   {
            char stringChar = userString2.charAt(i);
            if (userString2.indexOf(stringChar, userString2.indexOf(stringChar) + 1) != -1)   {
                hasDuplicate = true;
            }
        }
        
        //if else statement to output whether or not the program found one
        if (hasDuplicate)   {
            System.out.println();
            System.out.println( "\"" + userString2 + "\"" + " has duplicate letters.");
        }
        else   {
            System.out.println();
            System.out.println("\"" + userString2 + "\"" + " has no letters duplicated.");
        }
        
    }
}
