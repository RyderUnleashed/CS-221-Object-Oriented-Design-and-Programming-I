
/**
 * TicketBot is a rudimentary "barebones" program that simulates the purchase of travel tickets
 * This program was created to display the use of variables and scanner inputs
 * This program DOES NOT sell travel tickets
 *
 * @author Alex Griep
 * @version 9/16/2022
 */
import java.util.Scanner;
public class TicketBot
{
    public static void main (String[] args) 
    {
        Scanner input = new Scanner(System.in);
        String usrName;
        String usrDestination;
        int numTickets;
        double ticketPrice;
        
        //Requests the user's name
        System.out.println("Welcome to TicketBot!");
        System.out.print("Please start with your full name: ");
        usrName = input.nextLine();
        System.out.println("Thank you "+ usrName +"!" );
        
        //Asks the desired amount of tickets
        System.out.print("How many tickets do you need?: ");
        numTickets = input.nextInt();
        input.nextLine();
        System.out.println("I will search for options with " + numTickets + " ticket(s) available!");
        
        //Asks the user's destination
        System.out.print("Where is it that you would like tickets to?: ");
        usrDestination = input.nextLine();
        System.out.println(usrDestination + "! I wish I could join you!");
        
        //Asks the user's preferred budget
        System.out.print("How much are you hoping to spend maximum?: $");
        ticketPrice = input.nextDouble();
        input.nextLine();
        
        //Summarize's the user's inputs and "Loading options..." ends the program
        System.out.println("Understood, I won't show you options above $" + ticketPrice);
        System.out.println("To summarize, you would like:");
        System.out.println(numTickets + " ticket(s) to " + usrDestination);
        System.out.println("at no more than $" + ticketPrice + " per ticket.");
        System.out.println("Loading options...");
        
    }
}
