import java.util.Random;
/**
 * This class works with methods. The first method, "generateUsername", takes three hardcoded calls and generates a username based off of the string.
 * The second method, "charNTimes", takes three more hardcoded calls and prints the inputted character however many times.
 * The third method, "maskN", takes three more hardcoded calls and prints the string, masking with the character however many times.
 *
 * @author Alex
 * @version 11/17/2022
 */
public class Methods
{
    public static String generateUsername(String usersName)   {
        //Builds a new random number generator
        Random rand = new Random();
        
        //Gathers what we need to put together the username
        int space = usersName.indexOf(" ");
        String userLast = usersName.substring(space, space + 6);
        char userFirst = usersName.charAt(0);
        
        //puts it all together and returns it as a lowercase string
        String genUsername = userLast + userFirst + rand.nextInt(10) + rand.nextInt(10);
        return genUsername.toLowerCase();
    }
    
    public static String charNTimes(char userChar, int numTimes)   {
        //Creates an empty string for the chars to be put in
        String returnStr = "";
        
        //Loops numTimes concatinating userChar to the empty string w/ each iteration
        for (int i = 0; i < numTimes; i++)   {
            returnStr += userChar;
        }
        
        //Returns the string
        return returnStr;
    }
    
    public static String maskN(String userStr, int numMask, char charMask)   {
        //Creates an empty string and an increment for 'while' loop
        int i = 0;
        String returnStr = "";
        
        //While the iteration is less than numMask, add the char to the string
        while (i < numMask)   {
            returnStr += charMask;
            i++;
        }
        
        //If numMask is less than the string, concatinate the rest of the string
        if (numMask < userStr.length())   {
            returnStr += userStr.substring(numMask);
        }
        
        //Returns the string
        return returnStr;
    }
    
    public static void main(String[] args)   {
        //Testing the method "generateUsername" below using three hardcoded calls
        System.out.printf("%s %s \n", "Generating username for \"Samuel Clemmins\": ", generateUsername("Samuel Clemmins"));
        System.out.printf("%s %11s \n", "Generating username for \"Joseph Konrad\": ", generateUsername("Joseph Konrad"));
        System.out.printf("%s %13s \n", "Generating username for \"Franz Kafka\": ", generateUsername("Franz Kafka")); System.out.println();
        
        //Testing the method "charNTimes" below using three more hardcoded calls
        System.out.printf("%s %s \n", "Generating '-' 20 times: ", charNTimes('-', 20));
        System.out.printf("%s %5s \n", "Generating '*' 4 times: ", charNTimes('*', 4));
        System.out.printf("%s %s \n", "Generating '$' 10 times: ", charNTimes('$', 10)); System.out.println();
        
        //Testing the method "maskN" below using three more hardcoded calls
        System.out.printf("%s %s \n", "Generating \"4321654387657239\" masked with 12 '*'s: ", maskN("4321654387657239", 12, '*'));
        System.out.printf("%s %18s \n", "Generating \"password\" masked with 10 'x's: ", maskN("password", 10, 'x'));
        System.out.printf("%s %17s \n", "Generating \"onomatopoeia\" masked with 8 '?'s: ", maskN("onomatopoeia", 8, '?')); System.out.println();
    }
}
